# Vulnerable Code Repository (Test Fixtures)

This repository is an **intentionally vulnerable** collection of code samples
used for testing static analysis tools, scanner accuracy, and AI-driven
remediation workflows. **Do not deploy any of this code.** Every file
contains a known, deliberately introduced weakness, labeled with its CWE ID
in a header comment at the top of the file.

## Language Breakdown (25 files)

| Category | Languages | File Count |
|---|---|---|
| Popular (baseline) | JavaScript, Go, C# | 3 |
| Popular (extended) | Python, Java | 16 (8 each) |
| Systems | C++ | 1 |
| Enterprise / Legacy | Gosu, COBOL, ABAP, Perl, Groovy | 5 |
| **Total** | | **25** |

## File-to-CWE Mapping

| File | Language | CWE | Weakness |
|---|---|---|---|
| `src/python/user_search.py` | Python | CWE-89 | SQL Injection |
| `src/python/diagnostics.py` | Python | CWE-78 | OS Command Injection |
| `src/python/session_cache.py` | Python | CWE-502 | Insecure Deserialization |
| `src/python/file_download.py` | Python | CWE-22 | Path Traversal |
| `src/python/payments_config.py` | Python | CWE-798 | Hard-coded Credentials |
| `src/python/webhook_fetch.py` | Python | CWE-918 | Server-Side Request Forgery |
| `src/python/xml_import.py` | Python | CWE-611 | XML External Entity (XXE) |
| `src/python/auth_hashing.py` | Python | CWE-327 | Broken/Risky Crypto Algorithm |
| `src/java/ProductSearchServlet.java` | Java | CWE-89 | SQL Injection |
| `src/java/InvoiceXmlParser.java` | Java | CWE-611 | XML External Entity (XXE) |
| `src/java/SessionTokenHandler.java` | Java | CWE-502 | Insecure Deserialization |
| `src/java/ReportDownloadServlet.java` | Java | CWE-22 | Path Traversal |
| `src/java/LdapUserLookup.java` | Java | CWE-90 | LDAP Injection |
| `src/java/DatabaseConfig.java` | Java | CWE-798 | Hard-coded Credentials |
| `src/java/TokenGenerator.java` | Java | CWE-330 | Insufficiently Random Values |
| `src/java/AccountDetailsServlet.java` | Java | CWE-639 | Authorization Bypass (IDOR) |
| `src/javascript/profile_settings.js` | JavaScript | CWE-79 / CWE-1321 | XSS / Prototype Pollution |
| `src/go/orders_service.go` | Go | CWE-89 / CWE-918 | SQL Injection / SSRF |
| `src/csharp/CustomerController.cs` | C# | CWE-89 / CWE-502 | SQL Injection / Insecure Deserialization |
| `src/cpp/request_logger.cpp` | C++ | CWE-120 / CWE-134 | Buffer Overflow / Format String |
| `src/gosu/ClaimLookupHandler.gs` | Gosu | CWE-89 | SQL Injection (Guidewire) |
| `src/cobol/ACCTBAL.cbl` | COBOL | CWE-20 / CWE-787 | Improper Input Validation / OOB Write |
| `src/abap/zcustomer_search.abap` | ABAP | CWE-89 | SQL Injection (dynamic Open SQL) |
| `src/perl/network_tools.pl` | Perl | CWE-78 | OS Command Injection |
| `src/groovy/BuildConfigImporter.groovy` | Groovy | CWE-611 / CWE-502 | XXE / Insecure Deserialization |

## Usage

Each file is self-contained and includes a comment block explaining:
1. The CWE classification
2. Why the code is vulnerable
3. Where the unsafe sink is located

These are designed to be ingested by knowledge-driven remediation tooling,
SAST/DAST scanners, or used as training fixtures for secure-code-review
exercises. See `findings.json` for a machine-readable manifest of all 25
findings, suitable for bulk import into a vulnerability tracker.

## Disclaimer

This code is for security testing and educational purposes only. It is
intentionally insecure and must never be used in production systems.
